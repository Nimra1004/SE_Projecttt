﻿using System.Web.Mvc;


namespace BootstrapSite2.Controllers
{
    
    
    public class BlogController : Controller
    {
        
        public ActionResult Home2()
        {
            return View();
        }
    }
}
