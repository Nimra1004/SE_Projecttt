﻿using System.Web.Mvc;

namespace BootstrapSite2.Controllers
{
    public class AboutController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}