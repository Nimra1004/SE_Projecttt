﻿using System.Web.Mvc;

namespace BootstrapSite2.Controllers
{
    public class ContactController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}